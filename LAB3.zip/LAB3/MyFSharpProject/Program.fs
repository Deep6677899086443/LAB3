﻿// Define the Coach record
type Coach = {
    Name: string
    FormerPlayer: bool
}

// Define the Stats record
type Stats = {
    Wins: int
    Losses: int
}

// Define the Team record
type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}

// Create the teams with associated coaches and stats
let teams = [
    { Name = "Los Angeles Lakers"; Coach = { Name = "Darvin Ham"; FormerPlayer = true }; Stats = { Wins = 45; Losses = 37 } }
    { Name = "Golden State Warriors"; Coach = { Name = "Steve Kerr"; FormerPlayer = true }; Stats = { Wins = 44; Losses = 38 } }
    { Name = "Brooklyn Nets"; Coach = { Name = "Jacque Vaughn"; FormerPlayer = true }; Stats = { Wins = 40; Losses = 42 } }
    { Name = "Miami Heat"; Coach = { Name = "Erik Spoelstra"; FormerPlayer = false }; Stats = { Wins = 47; Losses = 35 } }
    { Name = "Boston Celtics"; Coach = { Name = "Joe Mazzulla"; FormerPlayer = false }; Stats = { Wins = 54; Losses = 28 } }
]

// Filter the successful teams (Wins > Losses)
let successfulTeams = 
    teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)

// Map the teams to their success percentage
let successPercentage team =
    let totalGames = float (team.Stats.Wins + team.Stats.Losses)
    let successRate = (float team.Stats.Wins / totalGames) * 100.0
    successRate

let teamSuccessPercentages =
    teams |> List.map (fun team -> (team.Name, successPercentage team))
    
// Print the results
successfulTeams |> List.iter (fun team -> printfn "%s - Wins: %d, Losses: %d" team.Name team.Stats.Wins team.Stats.Losses)
teamSuccessPercentages |> List.iter (fun (name, percentage) -> printfn "%s - Success Percentage: %.2f%%" name percentage)


//Second Part
// Define the Cuisine discriminated union
type Cuisine =
    | Korean
    | Turkish

// Define the MovieType discriminated union
type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

// Define the Activity discriminated union
type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float // number of kilometers (int), fuel charge per km (float)

// Define the function to calculate the budget based on the activity
let calculateBudget activity =
    match activity with
    | BoardGame -> 0.0 // Playing a board game costs 0 CAD
    | Chill -> 0.0 // Chilling out costs 0 CAD
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0 // Regular movie costs 12 CAD
        | IMAX -> 17.0 // IMAX movie costs 17 CAD
        | DBOX -> 20.0 // DBOX movie costs 20 CAD
        | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks -> 
            match movieType with
            | RegularWithSnacks | IMAXWithSnacks | DBOXWithSnacks -> 25.0 // +5 CAD for snacks
            | _ -> 12.0 // Default case if no snacks
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0 // Korean restaurant costs 70 CAD per couple
        | Turkish -> 65.0 // Turkish restaurant costs 65 CAD per couple
    | LongDrive (km, fuelPerKm) -> 
        // Convert kilometers to float before multiplying with fuelPerKm
        float km * fuelPerKm // Ensure both are floats

// Example activities
let activity1 = Movie Regular
let activity2 = Restaurant Korean
let activity3 = LongDrive (50, 1.2) // 50 km, 1.2 CAD per km

// Print the calculated budgets for different activities
printfn "Budget for activity1 (Movie): %.2f CAD" (calculateBudget activity1)
printfn "Budget for activity2 (Restaurant): %.2f CAD" (calculateBudget activity2)
printfn "Budget for activity3 (LongDrive): %.2f CAD" (calculateBudget activity3)

// Additional examples
let activity4 = Movie IMAXWithSnacks
let activity5 = Restaurant Turkish

printfn "Budget for activity4 (IMAXWithSnacks): %.2f CAD" (calculateBudget activity4)
printfn "Budget for activity5 (Restaurant - Turkish): %.2f CAD" (calculateBudget activity5)